http://classics.mit.edu/Antoninus/meditations.mb.txt
